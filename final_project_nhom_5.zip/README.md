# detect_cell_opencv
Detect cell in image with opencv (no deep learning)
